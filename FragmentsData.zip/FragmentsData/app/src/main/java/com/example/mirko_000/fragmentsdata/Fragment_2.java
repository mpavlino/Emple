package com.example.mirko_000.fragmentsdata;



import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Button;

public class Fragment_2 extends Fragment{

    View view;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // TODO Auto-generated method stub

        view = inflater.inflate(R.layout.fragment_fragment_2, container, false);
        return view;
    }

    public void setName(String gumbic)
    {
        //TextView btnName = (TextView) view.findViewById(R.id.btnViewResult);
       // btnName.setText("" + gumbic);
        Button btnName = (Button) view.findViewById(R.id.bttViewResult);
        btnName.setText(gumbic);


        btnName.setVisibility(View.VISIBLE); //SHOW the button



    }

}